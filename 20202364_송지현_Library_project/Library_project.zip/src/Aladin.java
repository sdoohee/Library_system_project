public class Aladin extends Bookstore {	
	public void notifyBook(String book_name) {
	}
}
