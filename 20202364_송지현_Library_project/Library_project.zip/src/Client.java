public interface Client {
	
	void setState(State state);
	
	void update(String text);
	
	void changeState();

}
