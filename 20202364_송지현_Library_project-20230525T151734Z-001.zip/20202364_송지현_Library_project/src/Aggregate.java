import java.util.Iterator;

public interface Aggregate {
	
	public abstract Iterator iterator();

}
