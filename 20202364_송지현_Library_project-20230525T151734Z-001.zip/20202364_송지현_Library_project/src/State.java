public interface State {
	public void push(User user, String text);
	public void set_notify(User user);
}
